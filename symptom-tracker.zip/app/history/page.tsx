"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { format } from "date-fns"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock } from "lucide-react"
import type { SymptomLog } from "@/types/symptom"
import { getSymptomLogs } from "@/lib/symptom-storage"

export default function SymptomHistory() {
  const [logs, setLogs] = useState<SymptomLog[]>([])

  useEffect(() => {
    setLogs(getSymptomLogs())
  }, [])

  const getSeverityColor = (severity: number) => {
    if (severity <= 3) return "bg-green-100 text-green-800 hover:bg-green-100"
    if (severity <= 7) return "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
    return "bg-red-100 text-red-800 hover:bg-red-100"
  }

  const groupedLogs = logs.reduce(
    (groups, log) => {
      const date = format(new Date(log.timestamp), "yyyy-MM-dd")
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(log)
      return groups
    },
    {} as Record<string, SymptomLog[]>,
  )

  return (
    <div className="container max-w-3xl mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-teal-600 hover:text-teal-700 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to dashboard
      </Link>

      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-teal-700">Symptom History</h1>
        <Link href="/log">
          <Button className="bg-teal-600 hover:bg-teal-700">Log New Symptom</Button>
        </Link>
      </div>

      {Object.keys(groupedLogs).length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-slate-500 mb-4">No symptom logs found</p>
            <Link href="/log">
              <Button className="bg-teal-600 hover:bg-teal-700">Log Your First Symptom</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        Object.entries(groupedLogs)
          .sort(([dateA], [dateB]) => new Date(dateB).getTime() - new Date(dateA).getTime())
          .map(([date, dayLogs]) => (
            <div key={date} className="mb-6">
              <div className="flex items-center mb-2">
                <Calendar className="h-4 w-4 text-teal-600 mr-2" />
                <h2 className="text-lg font-medium text-slate-700">{format(new Date(date), "EEEE, MMMM d, yyyy")}</h2>
              </div>

              <div className="space-y-3">
                {dayLogs
                  .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                  .map((log) => (
                    <Card key={log.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-medium text-slate-800">{log.symptom}</h3>
                            <div className="flex items-center text-xs text-slate-500 mt-1">
                              <Clock className="h-3 w-3 mr-1" />
                              {format(new Date(log.timestamp), "h:mm a")}
                            </div>
                          </div>
                          <Badge className={getSeverityColor(log.severity)}>Severity: {log.severity}</Badge>
                        </div>
                        {log.notes && (
                          <p className="mt-3 text-sm text-slate-600 border-t border-slate-100 pt-3">{log.notes}</p>
                        )}
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          ))
      )}
    </div>
  )
}

