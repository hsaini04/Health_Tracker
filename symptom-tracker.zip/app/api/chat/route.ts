import { type NextRequest, NextResponse } from "next/server"

// Define the system prompt for the health assistant
const SYSTEM_PROMPT = `
You are a helpful health assistant chatbot that helps users track and analyze their symptoms.
Your primary goals are:
1. Help users describe their symptoms in detail
2. Analyze symptoms and provide general health information
3. Detect when a user is describing a symptom that should be logged

IMPORTANT: You are NOT a doctor and should NOT provide medical diagnoses or treatment recommendations.
Always advise users to consult healthcare professionals for medical advice.

When a user describes a symptom, try to extract:
- The symptom name (headache, nausea, fatigue, etc.)
- The severity (on a scale of 1-10)
- Any additional notes or context

If you detect a symptom that should be logged, include a JSON object in your response like this:
###SYMPTOM_LOG###
{
  "symptom": "Headache",
  "severity": 7,
  "notes": "Throbbing pain on the right side, started after lunch"
}
###END_SYMPTOM_LOG###

Keep your responses conversational, empathetic, and helpful. Ask follow-up questions to get more details when needed.

You can use Markdown formatting in your responses to make them more readable:
- Use **bold** for emphasis
- Use *italic* for mild emphasis
- Use bullet points for lists
- Use numbered lists for steps
- Use headings for sections (# for main headings, ## for subheadings)
- Use > for important notes or quotes
- Use code blocks for any technical information

Format your responses in a clear, organized way using Markdown when appropriate.
`

// Gemini API endpoint
const GEMINI_API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()
    const GEMINI_API_KEY = process.env.GEMINI_API_KEY

    if (!GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY is not defined in environment variables")
    }

    // Format messages for Gemini API
    const formattedMessages = messages.map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }],
    }))

    // Add system prompt as the first message from the model
    formattedMessages.unshift({
      role: "model",
      parts: [{ text: SYSTEM_PROMPT }],
    })

    // Call Gemini API
    const response = await fetch(`${GEMINI_API_ENDPOINT}?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: formattedMessages,
        generationConfig: {
          temperature: 0.4,
          topK: 32,
          topP: 0.95,
          maxOutputTokens: 1024,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE",
          },
        ],
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      console.error("Gemini API error:", errorData)
      throw new Error(`Gemini API error: ${response.status}`)
    }

    const data = await response.json()
    const text = data.candidates[0]?.content?.parts[0]?.text || "I'm sorry, I couldn't generate a response."

    // Check if the response contains a symptom log
    let symptomToLog = null
    const symptomLogMatch = text.match(/###SYMPTOM_LOG###\s*({[\s\S]*?})\s*###END_SYMPTOM_LOG###/)

    let cleanedResponse = text

    if (symptomLogMatch && symptomLogMatch[1]) {
      try {
        symptomToLog = JSON.parse(symptomLogMatch[1])
        // Remove the symptom log JSON from the response
        cleanedResponse = text.replace(/###SYMPTOM_LOG###\s*{[\s\S]*?}\s*###END_SYMPTOM_LOG###/, "")
      } catch (error) {
        console.error("Error parsing symptom log:", error)
      }
    }

    return NextResponse.json({
      response: cleanedResponse.trim(),
      symptomToLog,
    })
  } catch (error) {
    console.error("Error in chat API:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}

