import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { PlusCircle, BarChart3, Settings, MessageCircle } from "lucide-react"

export default function Home() {
  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-teal-700">HealthTrack</h1>
        <p className="text-slate-600">Monitor your symptoms and gain health insights</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-teal-50 to-teal-100 border-teal-200">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold text-teal-800 mb-2">Quick Log</h2>
            <p className="text-slate-600 mb-4">Record your symptoms in just a few clicks</p>
            <Link href="/log">
              <Button className="bg-teal-600 hover:bg-teal-700">
                <PlusCircle className="mr-2 h-4 w-4" />
                Log Symptoms
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold text-blue-800 mb-2">Health Insights</h2>
            <p className="text-slate-600 mb-4">View trends and patterns in your health data</p>
            <Link href="/insights">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <BarChart3 className="mr-2 h-4 w-4" />
                View Insights
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold text-purple-800 mb-2">
              Gemini AI Health Assistant
              <span className="ml-2 text-xs bg-purple-200 text-purple-800 px-2 py-0.5 rounded-full">2.0 Flash</span>
            </h2>
            <p className="text-slate-600 mb-4">Chat with our AI to analyze symptoms and get help</p>
            <Link href="/chat">
              <Button className="bg-purple-600 hover:bg-purple-700">
                <MessageCircle className="mr-2 h-4 w-4" />
                Chat with Gemini
              </Button>
            </Link>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          {["Headache", "Fatigue", "Nausea", "Fever"].map((symptom) => (
            <Link href={`/log?symptom=${symptom}`} key={symptom}>
              <Card className="hover:bg-slate-50 transition-colors cursor-pointer h-full">
                <CardContent className="p-4 flex items-center justify-between">
                  <span className="font-medium text-slate-700">{symptom}</span>
                  <PlusCircle className="h-4 w-4 text-teal-600" />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {["Cough", "Muscle Pain", "Sore Throat", "Dizziness", "Rash", "Stomach Pain"].map((symptom) => (
          <Link href={`/log?symptom=${symptom}`} key={symptom}>
            <Card className="hover:bg-slate-50 transition-colors cursor-pointer">
              <CardContent className="p-4 flex items-center justify-between">
                <span className="font-medium text-slate-700">{symptom}</span>
                <PlusCircle className="h-4 w-4 text-teal-600" />
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <footer className="mt-12 flex justify-between items-center">
        <p className="text-sm text-slate-500">Track your health journey with HealthTrack</p>
        <Link href="/settings">
          <Button variant="ghost" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </Link>
      </footer>
    </div>
  )
}

