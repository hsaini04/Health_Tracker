"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { format, subDays } from "date-fns"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, BarChart3, TrendingUp, Calendar, AlertCircle } from "lucide-react"
import type { SymptomLog } from "@/types/symptom"
import { getSymptomLogs } from "@/lib/symptom-storage"
import { generateInsights } from "@/lib/insights-generator"

export default function Insights() {
  const [logs, setLogs] = useState<SymptomLog[]>([])
  const [insights, setInsights] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const symptomLogs = getSymptomLogs()
    setLogs(symptomLogs)

    if (symptomLogs.length > 0) {
      const generatedInsights = generateInsights(symptomLogs)
      setInsights(generatedInsights)
    }

    setIsLoading(false)
  }, [])

  // Group symptoms by name for the summary
  const symptomCounts = logs.reduce(
    (acc, log) => {
      acc[log.symptom] = (acc[log.symptom] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  // Calculate average severity by symptom
  const symptomSeverities = logs.reduce(
    (acc, log) => {
      if (!acc[log.symptom]) {
        acc[log.symptom] = { total: 0, count: 0 }
      }
      acc[log.symptom].total += log.severity
      acc[log.symptom].count += 1
      return acc
    },
    {} as Record<string, { total: number; count: number }>,
  )

  const averageSeverities = Object.entries(symptomSeverities)
    .map(([symptom, data]) => ({
      symptom,
      average: data.total / data.count,
    }))
    .sort((a, b) => b.average - a.average)

  // Get recent days for the trend view
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), i)
    return format(date, "yyyy-MM-dd")
  }).reverse()

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-teal-600 hover:text-teal-700 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to dashboard
      </Link>

      <h1 className="text-2xl font-bold text-teal-700 mb-6">Health Insights</h1>

      {logs.length === 0 ? (
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-medium text-slate-700 mb-2">No data available</h2>
            <p className="text-slate-500 mb-4">Start logging your symptoms to generate health insights</p>
            <Link href="/log">
              <Button className="bg-teal-600 hover:bg-teal-700">Log Your First Symptom</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="summary">
          <TabsList className="mb-6">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="ai-insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="summary">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-teal-700">
                    <div className="flex items-center">
                      <BarChart3 className="h-5 w-5 mr-2" />
                      Most Frequent Symptoms
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(symptomCounts)
                      .sort((a, b) => b[1] - a[1])
                      .slice(0, 5)
                      .map(([symptom, count]) => (
                        <div key={symptom} className="flex justify-between items-center">
                          <span className="font-medium text-slate-700">{symptom}</span>
                          <span className="text-sm text-slate-500">
                            {count} {count === 1 ? "time" : "times"}
                          </span>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-teal-700">
                    <div className="flex items-center">
                      <TrendingUp className="h-5 w-5 mr-2" />
                      Highest Severity Symptoms
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {averageSeverities.slice(0, 5).map(({ symptom, average }) => (
                      <div key={symptom} className="flex justify-between items-center">
                        <span className="font-medium text-slate-700">{symptom}</span>
                        <span className="text-sm text-slate-500">Avg: {average.toFixed(1)}/10</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="trends">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-teal-700">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    7-Day Symptom Trend
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {averageSeverities.slice(0, 3).map(({ symptom }) => (
                    <div key={symptom} className="space-y-2">
                      <h3 className="font-medium text-slate-700">{symptom}</h3>
                      <div className="flex items-center h-10">
                        {last7Days.map((date) => {
                          const dayLogs = logs.filter(
                            (log) => log.symptom === symptom && format(new Date(log.timestamp), "yyyy-MM-dd") === date,
                          )

                          const avgSeverity = dayLogs.length
                            ? dayLogs.reduce((sum, log) => sum + log.severity, 0) / dayLogs.length
                            : 0

                          return (
                            <div key={date} className="flex-1 flex flex-col items-center">
                              <div
                                className="w-full bg-teal-100 rounded-sm"
                                style={{
                                  height: avgSeverity ? `${avgSeverity * 10}%` : "4px",
                                  backgroundColor: avgSeverity ? `rgba(20, 184, 166, ${avgSeverity / 10})` : "#e2e8f0",
                                }}
                              />
                              <span className="text-xs text-slate-500 mt-1">{format(new Date(date), "dd")}</span>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-insights">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg text-teal-700">
                  <div className="flex items-center">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    AI-Generated Health Insights
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin h-8 w-8 border-4 border-teal-500 border-t-transparent rounded-full mx-auto mb-4" />
                    <p className="text-slate-500">Analyzing your health data...</p>
                  </div>
                ) : insights.length > 0 ? (
                  <ul className="space-y-4">
                    {insights.map((insight, index) => (
                      <li key={index} className="flex">
                        <span className="text-teal-500 mr-2">•</span>
                        <span className="text-slate-700">{insight}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-slate-500 text-center py-4">
                    Log more symptoms to receive AI-powered health insights
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

