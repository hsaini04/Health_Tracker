"use client"

import type React from "react"

import { useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"
import { ArrowLeft, Save } from "lucide-react"
import type { SymptomLog } from "@/types/symptom"
import { saveSymptomLog } from "@/lib/symptom-storage"

export default function LogSymptom() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const [symptom, setSymptom] = useState(searchParams.get("symptom") || "")
  const [severity, setSeverity] = useState(5)
  const [notes, setNotes] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!symptom.trim()) {
      toast({
        title: "Error",
        description: "Please enter a symptom name",
        variant: "destructive",
      })
      return
    }

    const newLog: SymptomLog = {
      id: Date.now().toString(),
      symptom,
      severity,
      notes,
      timestamp: new Date().toISOString(),
    }

    saveSymptomLog(newLog)

    toast({
      title: "Symptom logged",
      description: "Your symptom has been recorded successfully",
    })

    router.push("/history")
  }

  return (
    <div className="container max-w-2xl mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-teal-600 hover:text-teal-700 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to dashboard
      </Link>

      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-teal-700">Log a Symptom</CardTitle>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="symptom">Symptom Name</Label>
              <Input
                id="symptom"
                value={symptom}
                onChange={(e) => setSymptom(e.target.value)}
                placeholder="e.g., Headache, Nausea, Fatigue"
                className="border-teal-200 focus-visible:ring-teal-500"
              />
            </div>

            <div className="space-y-4">
              <Label>Severity (1-10)</Label>
              <div className="space-y-3">
                <Slider
                  value={[severity]}
                  min={1}
                  max={10}
                  step={1}
                  onValueChange={(value) => setSeverity(value[0])}
                  className="py-4"
                />
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Mild (1)</span>
                  <span>Moderate (5)</span>
                  <span>Severe (10)</span>
                </div>
              </div>
              <div className="text-center">
                <span className="text-2xl font-bold text-teal-700">{severity}</span>
                <p className="text-sm text-slate-500">
                  {severity <= 3 ? "Mild" : severity <= 7 ? "Moderate" : "Severe"}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any additional details about this symptom..."
                className="min-h-[100px] border-teal-200 focus-visible:ring-teal-500"
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700">
              <Save className="mr-2 h-4 w-4" />
              Save Symptom Log
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

