export interface SymptomLog {
  id: string
  symptom: string
  severity: number
  notes: string
  timestamp: string
}

