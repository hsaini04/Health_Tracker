import type { SymptomLog } from "@/types/symptom"

const STORAGE_KEY = "symptom_logs"

export function saveSymptomLog(log: SymptomLog): void {
  const logs = getSymptomLogs()
  logs.push(log)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(logs))
}

export function getSymptomLogs(): SymptomLog[] {
  if (typeof window === "undefined") {
    return []
  }

  const storedLogs = localStorage.getItem(STORAGE_KEY)
  return storedLogs ? JSON.parse(storedLogs) : []
}

export function clearAllSymptomLogs(): void {
  localStorage.removeItem(STORAGE_KEY)
}

