import type { SymptomLog } from "@/types/symptom"
import { subDays, isWithinInterval } from "date-fns"

export function generateInsights(logs: SymptomLog[]): string[] {
  const insights: string[] = []

  if (logs.length === 0) {
    return insights
  }

  // Get most frequent symptom
  const symptomCounts = logs.reduce(
    (acc, log) => {
      acc[log.symptom] = (acc[log.symptom] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const mostFrequentSymptom = Object.entries(symptomCounts).sort((a, b) => b[1] - a[1])[0]

  if (mostFrequentSymptom) {
    insights.push(`Your most reported symptom is ${mostFrequentSymptom[0]} (${mostFrequentSymptom[1]} times).`)
  }

  // Get highest severity symptom
  const symptomSeverities = logs.reduce(
    (acc, log) => {
      if (!acc[log.symptom]) {
        acc[log.symptom] = { total: 0, count: 0 }
      }
      acc[log.symptom].total += log.severity
      acc[log.symptom].count += 1
      return acc
    },
    {} as Record<string, { total: number; count: number }>,
  )

  const averageSeverities = Object.entries(symptomSeverities)
    .map(([symptom, data]) => ({
      symptom,
      average: data.total / data.count,
    }))
    .sort((a, b) => b.average - a.average)

  if (averageSeverities.length > 0) {
    const highestSeverity = averageSeverities[0]
    insights.push(
      `${highestSeverity.symptom} has your highest average severity rating (${highestSeverity.average.toFixed(1)}/10).`,
    )
  }

  // Check for patterns in the last 7 days
  const now = new Date()
  const last7Days = Array.from({ length: 7 }, (_, i) => subDays(now, i))

  const recentLogs = logs.filter((log) => {
    const logDate = new Date(log.timestamp)
    return isWithinInterval(logDate, {
      start: subDays(now, 7),
      end: now,
    })
  })

  if (recentLogs.length > 0) {
    // Check for increasing severity trends
    const symptomTrends = {} as Record<string, SymptomLog[]>

    recentLogs.forEach((log) => {
      if (!symptomTrends[log.symptom]) {
        symptomTrends[log.symptom] = []
      }
      symptomTrends[log.symptom].push(log)
    })

    Object.entries(symptomTrends).forEach(([symptom, symptomLogs]) => {
      if (symptomLogs.length >= 3) {
        // Sort by timestamp
        symptomLogs.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())

        // Check if severity is increasing
        let increasing = true
        for (let i = 1; i < symptomLogs.length; i++) {
          if (symptomLogs[i].severity <= symptomLogs[i - 1].severity) {
            increasing = false
            break
          }
        }

        if (increasing) {
          insights.push(
            `Your ${symptom} severity has been increasing over time. Consider consulting a healthcare professional.`,
          )
        }
      }
    })
  }

  // Add general insights if we don't have many specific ones
  if (insights.length < 2) {
    insights.push("Continue logging your symptoms regularly to receive more personalized insights.")

    if (logs.length < 5) {
      insights.push("We need more data to provide accurate health insights. Try logging symptoms daily.")
    }
  }

  return insights
}

